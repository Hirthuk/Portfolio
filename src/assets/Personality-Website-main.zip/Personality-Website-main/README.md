Webiste created using Html,ejs,css, Express using public API to generate - Programming Quotes/Life quotes/life advice/Meme

Use npm i --- to install the packages mentioned
move to the downloaded directory
use nodemon index.js
it will open the server is localhost: 3000 -- port
start exploring the simple public api website to generate random quotes and memes
